first run catkin_make and source devel/setup.bash
the run the following steps:
1) roslaunch turtle_vis Turtlevis.launch
2) rosservice call /TurtlePose "p:
x:2.0
y:2.0
theta: 1.57"
3)rosrun turtle_vis turtle_set_position
1
1
1


