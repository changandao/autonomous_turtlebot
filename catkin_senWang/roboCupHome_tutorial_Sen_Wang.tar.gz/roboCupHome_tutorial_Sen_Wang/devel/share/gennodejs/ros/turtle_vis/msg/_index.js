
"use strict";

let DesiredPose = require('./DesiredPose.js');

module.exports = {
  DesiredPose: DesiredPose,
};
