progenitor(john, james).
progenitor(john, janet).
progenitor(ruth, james).
progenitor(ruth, janet).
progenitor(emma, john).
progenitor(katherine, ruth).
progenitor(alfred, john).
progenitor(edgar, ruth).
male(john).
male(james).
female(janet).
female(ruth).
female(katherine).
male(alfred).
male(edgar).
female(emma).
grandfather(X,Z):-male(X), progenitor(Y,Z), progenitor(X,Y).
grandson(X,Z):-male(X),progenitor(Y,X),progenitor(Z,Y).
son(X,Y):-progenitor(Y,X),male(X).
brother(X,Z):-progenitor(Y,X),progenitor(Y,Z),male(X),male(Z),X\=Z.
