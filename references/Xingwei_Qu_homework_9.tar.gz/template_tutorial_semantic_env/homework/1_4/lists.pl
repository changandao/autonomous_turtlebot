p([a, b, c]).
q([17, 13, 11, 7, 5, 3, 2]).
r([orange, orange, apple, banana]).
s([X, f(A), hello, 3, -9.4]).
t([a, [a, a], [a, [a, a]], a]).
u([the, [ ], has, nothing, in, it]).
w([H|T], H, T).
