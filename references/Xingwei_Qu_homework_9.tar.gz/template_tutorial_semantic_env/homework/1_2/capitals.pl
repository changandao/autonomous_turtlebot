capital(berlin,germany).
capital(athens,greece).
capital(madrid,spain).
start:-write('Which country or capital do you want to know? '),nl, write('Write the
capital or the country in lower letters and end it with a dot.'), nl,read(A), process(A).
process(A):- capital(X,A),result(A,X).
process(A):- capital(A,X),result(X,A).
result(X,Y):-write(X), write(' the capital is '),write(Y),write('.'), nl.
