/* ***************************************
	Author:	Karinne Ramirez-Amaro
	E-mail:	karinne.ramirez@tum.de

 This library contains predicates used for the 
 inference method using prolog queries. 


 NOTE: The following symbols are used to describe the parameter 
of the predicates
 + The argument is instantiated at entry.
 - The argument is not instantiated at entry.
 ? The argument is unbound or instantiated at entry.

*/

:- module(queriesExercise3,
    [
	expected_position/2,
	yourPredicate/2
	%%TODO: Include the prolog queries you want to access from the terminal
    ]).


:- owl_parser:owl_parse('package://knowrob_map_data/owl/ccrl2_semantic_map.owl').
:- rdf_db:rdf_register_ns(knowrob, 'http://knowrob.org/kb/knowrob.owl#', [keep(true)]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Please create here your prolog queries
%%% to answer the questions from the slides
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
where(Place):- Class1='http://knowrob.org/kb/knowrob.owl#Cup',expected_position(Place,Class1);Class2='http://knowrob.org/kb/knowrob.owl#Glass',expected_position(Place,Class2).

object(S):-Class = 'http://knowrob.org/kb/knowrob.owl#Refrigerator67',storagePlaceFor(S,Class).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TODO: Properly document your predicates
% Describe the purpose of this query
% e.g.  query will return the expected storage place of a given class

%% This query will return the expected storage place of a given class
%
% expected_position(-Place, +Class)
% @param Class		represents the name of the class where the instance will be created. 
%			This variable cannot be empty and this Class could be of the forms: 
%			Class='http://knowrob.org/kb/knowrob.owl#Cup' (the desired URL)
%			
% @param Place		reasoned stored place for the objects
%
% eg: Class='http://knowrob.org/kb/knowrob.owl#Cup', expected_position(Place, Class).

expected_position(Place,Class):-
	storagePlaceFor(Place, Class),
	write('Expected place:'), nl.




yourPredicate(A,B):-
        storagePlaceFor(A,B),
	write('Something:'), nl.

