 roslaunch simple_navigation_goals navigaiton.launch 

