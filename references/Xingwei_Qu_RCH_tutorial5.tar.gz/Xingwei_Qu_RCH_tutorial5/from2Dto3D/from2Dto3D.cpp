#include <ros/ros.h>
#include <ros/console.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <geometry_msgs/Point.h>
#include <std_msgs/Char.h>

#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/exact_time.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <tf/transform_listener.h>

#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>


#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>


// PCL specific includes
#include <pcl_ros/point_cloud.h> // enable pcl publishing
#include <sensor_msgs/PointCloud2.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/PCLPointCloud2.h>

//#include <image_geometry/pinhole_camera_model.h>


#include <perception_msgs/Rect.h>



using namespace std;
using namespace cv;


class From2Dto3D
{

    private:
      //! The node handle
      ros::NodeHandle nh_;
      //! Node handle in the private namespace
      ros::NodeHandle priv_nh_;

      //! Define publishers and subscribers
      ros::Subscriber sub_name;
      ros::Subscriber sub;
      ros::Publisher pub_name;

      //! Define the pointcloud structure and the bounding box local copy

      int boundingbox_x;
      int boundingbox_y;
      //! A tf transform listener if needed
      tf::TransformListener listener_;


      //------------------ Callbacks -------------------

      //! Process clusters
      void processCloud(const sensor_msgs::PointCloud2ConstPtr& pc);
      //! Process bounding boxes
      void processRect(const perception_msgs::RectConstPtr & r);


    public:
      //! Subscribes to and advertises topics
      From2Dto3D(ros::NodeHandle nh) : nh_(nh), priv_nh_("~")
      {

        // subscribers to the bounding boxes and the point cloud
        // format:
        sub_name = nh_.subscribe<sensor_msgs::PointCloud2>("/kinect2/sd/points", 10, &From2Dto3D::processCloud, this);
        sub = nh_.subscribe<perception_msgs::Rect>("/face_detection/bb", 10, &From2Dto3D::processRect, this);
        // Publishers
        // format:
        pub_name = nh_.advertise<geometry_msgs::Point>("/3D_point", 10);

        ROS_INFO("from2Dto3D initialized ...");

      }

      ~From2Dto3D() {}
};


void From2Dto3D::processCloud(const sensor_msgs::PointCloud2ConstPtr& pc)
{    
    // store local data copy or shared, depending on the message
    pcl::PCLPointCloud2 pcl_pc2;
    pcl_conversions::toPCL(* pc,pcl_pc2);
    pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_pc(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromPCLPointCloud2(pcl_pc2,*pcl_pc);
    geometry_msgs::Point pointmsg;

        int width=pcl_pc->width;
        pointmsg.x = pcl_pc->points[boundingbox_x+boundingbox_y*width+1].x;
        pointmsg.y = pcl_pc->points[boundingbox_x+boundingbox_y*width+1].y;
        pointmsg.z = pcl_pc->points[boundingbox_x+boundingbox_y*width+1].z;
        pub_name.publish(pointmsg);









}

void From2Dto3D::processRect(const perception_msgs::RectConstPtr& r)
{
    boundingbox_x=r->x+r->width/2;
    boundingbox_y=r->y+ r->height/2;

}



int main(int argc, char** argv)
{
    ros::init(argc, argv, "from2Dto3D");
    ros::NodeHandle nh;
    From2Dto3D node(nh);
    ros::spin();
    return 0;
}


