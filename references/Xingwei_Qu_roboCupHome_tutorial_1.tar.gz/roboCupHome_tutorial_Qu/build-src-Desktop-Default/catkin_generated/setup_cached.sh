#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default/devel/lib:$LD_LIBRARY_PATH"
export PATH="/opt/ros/indigo/bin:/usr/lib/x86_64-linux-gnu/qt5/bin:/usr/bin:/usr/lib/x86_64-linux-gnu/qt5/bin:/usr/bin:/home/quxingwei/anaconda2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games"
export PKG_CONFIG_PATH="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PWD="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default"
export PYTHONPATH="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/build-src-Desktop-Default/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/src:$ROS_PACKAGE_PATH"