# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/quxingwei/ros/workspace/roboCupHome_tutorial_Qu/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/opt/ros/indigo".split(';') if "/opt/ros/indigo" != "" else []
