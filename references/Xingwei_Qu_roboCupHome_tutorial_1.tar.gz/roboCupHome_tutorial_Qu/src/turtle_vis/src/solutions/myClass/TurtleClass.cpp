#include<turtle_vis/myClass/TurtleClass.h>

namespace turtleSpace {

TurtleClass::TurtleClass()
{

//    double TURTLE_CLASS_MEMBER_VARIABLE;
    //Vector3d *turtlePose_g,  Vector3d turtlePose_desired_g;
    //#>>>>TODO: INITIALIZE MEMBER VARIABLES
    Vector3d turtlePose_desired_g, turtlePose_g ;
    count_mutex = PTHREAD_MUTEX_INITIALIZER;


}
TurtleClass::~TurtleClass()
{

}

void TurtleClass::getPose(const turtle_vis::DesiredPose::ConstPtr &msg)
{
    pthread_mutex_lock( &this->count_mutex );
    turtlePose_g[0] = msg->x;
    turtlePose_g[1] = msg->y;
    turtlePose_g[2] = msg->theta;

    //#>>>>TODO: COPY THE MSG TO A LOCAL VARIABLE
    pthread_mutex_unlock( &this->count_mutex );
    //Vector3d *turtlePose_g;
    //turtlePose_g=msg;
    //#>>>>TODO:PLOT THE OBTAINED DATA
    std::cout << turtlePose_g << std::endl;
}

bool TurtleClass::getDPose(turtle_vis::send_desired_pose::Request &req, turtle_vis::send_desired_pose::Response &res)
{
    pthread_mutex_lock( &this->count_mutex );
    //#>>>>TODO:COPY THE REQUEST MSG TO A LOCAL VARIABLE

    pthread_mutex_unlock( &this->count_mutex );
    //Vector3d turtlePose_desired_g ;
    turtlePose_desired_g[0]=req.x;
    turtlePose_desired_g[1]=req.y;
    turtlePose_desired_g[2]=req.theta;
    //#>>>>TODO:PLOT THE OBTAINED DATA
    std::cout << turtlePose_desired_g << std::endl;
    res.reply=1;

    return true;
}

Vector3d TurtleClass::getLocalPose()
{
    Vector3d local;
    pthread_mutex_lock( &this->count_mutex );
    local=this->turtlePose_g;
    pthread_mutex_unlock( &this->count_mutex );

    return local;
}

Vector3d TurtleClass::getLocalDesiredPose()
{
    Vector3d local;

    pthread_mutex_lock( &this->count_mutex );
    local=this->turtlePose_desired_g;
    pthread_mutex_unlock( &this->count_mutex );

    return local;
}




}
