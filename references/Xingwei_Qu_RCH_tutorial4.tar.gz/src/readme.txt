roslaunch hri image_processing.launch 

