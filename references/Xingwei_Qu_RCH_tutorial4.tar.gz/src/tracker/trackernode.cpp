//C++ related includes.
#include <cstdio>
#include <cmath>
#include <sys/stat.h>
#include <iostream>
#include <fstream>
#include <sstream>

//ROS related includes.
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <std_msgs/String.h>
#include <message_filters/subscriber.h>




//OpenCV related includes.
#include <cv_bridge/cv_bridge.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

//Self defined includes.
#include "cf_libs/kcf/kcf_tracker.hpp"
#include <perception_msgs/Rect.h>



//Debug defines
#define DEBUG
//#define INHIBITION

// constant defines

//Function declarations.
void callbackimage(const sensor_msgs::ImageConstPtr &_img);
void callbackbb(const perception_msgs::RectConstPtr &_bb);
//Global variables.
bool newImage = false;
bool newBB = false;
cv::Mat out_img;
cv_bridge::CvImagePtr in_img;
cv_bridge::CvImage out_aux_img;
sensor_msgs::Image out_imgmsg;

perception_msgs::Rect in_bb;


int main(int argc, char *argv[])
{


    //The node's name.
    std::string name = "tracker";

    //Initialize ROS.
    ros::init(argc, argv, name);
    ros::NodeHandle node;

    
    int queuesize = 2; //
    //ros::Subscriber sub_im = node.subscribe<sensor_msgs::Image>("/camera/rgb", queuesize, callbackimage);
    ros::Subscriber sub_im = node.subscribe<sensor_msgs::Image>("/kinect2/qhd/image_color_rect", queuesize, callbackimage);
    ros::Subscriber sub_bb = node.subscribe<perception_msgs::Rect>("face_detection/bb", queuesize, callbackbb);
    ros::Publisher pub_bb = node.advertise<perception_msgs::Rect>("tracker/bb", queuesize);


    // tracker parameters
    const double MAX_TIME_TRACK = 5.0;
	// create tracker
	cf_tracking::KcfParameters paras;
	paras.enableTrackingLossDetection = true;
    //paras.psrThreshold = 10; // lower more flexible
    paras.psrThreshold = 13.5; // higher more restricted to changes
	paras.psrPeakDel = 2;//1;
	std::vector< cf_tracking::KcfTracker * > vKCF;
	cf_tracking::KcfTracker * cKCF;

    // output messages    
    std::vector< cv::Rect > vbb;    
    std::vector< double > vtimestamp;
	cv::Rect bb(0,0,0,0);
	cv::Mat img;

    bool tracking = false; // the tracker is running
	
    ROS_INFO("Tracker initialized...");
    while(ros::ok())
    {
        ros::spinOnce();        
        if(newImage){
            cv::resize(in_img->image, img, cv::Size(), 0.5, 0.5); //img = in_img->image;
            if (newBB && !tracking){
                bb = cv::Rect( in_bb.x, in_bb.y, in_bb.width, in_bb.height);
                cKCF = new cf_tracking::KcfTracker(paras);
                if ( cKCF->reinit(img, bb) ) {
                    vKCF.push_back(cKCF);
                    vbb.push_back(bb);
                    vtimestamp.push_back(ros::Time::now().toSec());
                    tracking = true;
                }
                else delete cKCF;
            }// end new face detection to track
			std::vector<uint> eliminate;
            bool timeloss;
            bool trackloss;
            bool _targetOnFrame = false;
            for (uint i = 0; i < vKCF.size(); ++i) {
                _targetOnFrame = vKCF[i]->update(img, vbb[i]);
                timeloss = (  (ros::Time::now().toSec() - vtimestamp[i]) >  MAX_TIME_TRACK );//time
                trackloss = (! (_targetOnFrame && vbb[i].width && vbb[i].height) ); // tracking loss
                if (trackloss || timeloss) {
                    eliminate.push_back(i);
				}
			}
			// remove tracks faliures
			for (uint i = 0; i < eliminate.size(); ++i) {
				delete vKCF[eliminate[i]-i];				
				vKCF.erase(vKCF.begin()+eliminate[i]-i);
                vbb.erase(vbb.begin()+eliminate[i]-i);
                vtimestamp.erase(vtimestamp.begin()+eliminate[i]-i);
                tracking = false;
			}

            // publish updated tracked locations            
            perception_msgs::Rect bbpub;
			bbpub.header = in_img->header;            
			for (uint i = 0; i < vbb.size(); ++i) {
                bbpub.x = vbb[i].x; bbpub.y = vbb[i].y;
                bbpub.width = vbb[i].width; bbpub.height = vbb[i].height;
            }
            if (tracking) {
                pub_bb.publish(bbpub);
            }



			
	#ifdef DEBUG
			cv::cvtColor(img, out_img, CV_BGR2GRAY);			
			cv::cvtColor(out_img, out_img, CV_GRAY2BGR);
			for (uint i = 0; i < vbb.size(); ++i){
				bb = vbb[i];                
				if (bb.width && bb.height){
					cv::Point tl = bb.tl();
					cv::Point br = bb.br();
                    cv::Scalar color = cv::Scalar(0,0,0);									
                    color = cv::Scalar(0, 255, 0);                    
                    rectangle(out_img, bb, color, 2);
                    cv::circle(out_img, cv::Point((tl+br))*0.5, 3, cv::Scalar(0,0,255), 2);
				}
			}
			cv::imshow("Tracked object", out_img);
			cv::waitKey(1);	
	#endif				
			newImage = false;
            newBB = false;
		}
	}
	// erase tracker
	for (std::vector< cf_tracking::KcfTracker *>::iterator it = vKCF.begin(); it != vKCF.end(); ++it)
		delete (*it);
	vKCF.clear();
    
    return 0;
}

////
// This function reads camera image
void callbackimage(const sensor_msgs::ImageConstPtr &_img)
{
    in_img = cv_bridge::toCvCopy(_img, sensor_msgs::image_encodings::BGR8);    
    newImage = true;    
}

///
// This function reads the bounding box to track
void callbackbb(const perception_msgs::RectConstPtr &_bb)
{
    in_bb = perception_msgs::Rect(*_bb);
    newBB = true;
}


