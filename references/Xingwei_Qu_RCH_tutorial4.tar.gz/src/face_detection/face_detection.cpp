#include <ros/ros.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <sensor_msgs/Image.h>
#include <perception_msgs/Rect.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/objdetect/objdetect.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <iostream>
#include <vector>
using namespace cv;
using namespace std;

class Facedetection{


    ros::NodeHandle nh_;
    image_transport::ImageTransport it_;
    ros::Publisher bb_pub_;
    image_transport::Subscriber image_sub_;
public:
    Facedetection()
        : it_(nh_)
    {

    bb_pub_ = nh_.advertise<perception_msgs::Rect>("face_detection/bb",1);

    image_sub_ = it_.subscribe("/kinect2/qhd/image_color_rect",1,&Facedetection::imagecallback,this);
    namedWindow("Face");

    }
    ~Facedetection()
    {
        destroyWindow("Face");
    }
    /*Mat cv_im;
    Mat im_gray;
    CascadeClassifier face_cascade;
    std::vector<Rect> faces;
    perception_msgs::Rect r;*/
    //void imagecallback(const sensor_msgs::ImageConstPtr& image);

    void imagecallback(const sensor_msgs::ImageConstPtr& image){
   /* try
    {
        cv_bridge::CvImageConstPtr cv_ptr = cv_bridge::toCvShare(image,sensor_msgs::image_encodings::BGR8);
    }
    catch(cv_bridge::Exception& e){
        ROS_ERROR("CVBRIDGE:{}");
        return;

    }*/
    cv_bridge::CvImagePtr cv_ptr;
    try{

    cv_ptr = cv_bridge::toCvCopy(image,sensor_msgs::image_encodings::BGR8);
        }
    catch(cv_bridge::Exception& e){
    ROS_ERROR("CVBRIDGE:{} %s",e.what());
    return;

        }
    //cv::Mat cv_im;
    resize(cv_ptr->image,cv_ptr->image,cv::Size(),0.5,0.5);
    cv::Mat im_gray;
    cvtColor(cv_ptr->image,im_gray, CV_BGR2GRAY);
    CascadeClassifier face_cascade = CascadeClassifier("/home/athomews17/catkin_ws/src/face_detection/haarcascade_frontalface_alt.xml");
    vector<Rect> faces;
    face_cascade.detectMultiScale(im_gray,faces,1.3,5);
    perception_msgs::Rect r;
    for (int i=0; i<faces.size();i++){


        r.x = faces[i].x;
        r.y = faces[i].y;
        r.width = faces[i].width;
        r.height = faces[i].height;
        rectangle(cv_ptr->image,cv::Point(faces[i].x,faces[i].y),cv::Point(faces[i].x+faces[i].width,faces[i].y+faces[i].height),Scalar(0,255,0),2);
        bb_pub_.publish(r);
    }




    //rectangle(cv_ptr->image,cv::Point(faces[0].x,faces[0].y),cv::Point(faces[0].x+faces[0].width,faces[0].y+faces[0].height),Scalar(0,255,0),2);
    cv::imshow("Face",cv_ptr->image);
    cv::waitKey(3);



	




    }
};



int main(int argc, char** argv){
    //Facedetection::imagecallback &imagedeal;
    ros::init(argc,argv,"face_detection");
    //ros::NodeHandle n;
    //ros::Subscriber image_sub = n.subscribe("/kinect2/hd/image_color",&Facedetection::imagecallback);
    //ros::Publisher bb_pub = n.advertise<perception_msgs::Rect>("face_detection/bb",1);
    //perception_msgs::Rect r;
    //r = imagedeal.r;
    //bb_pub.publish(r);
    Facedetection ic;
    ros::spin();
    


    return 0;
}
