#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

robocup@home ICS TUM
Pablo Lanillos
"""


import rospy
import cv2 # opencv code for images
from cv_bridge import CvBridge, CvBridgeError
import time
from std_msgs.msg import String
from std_msgs.msg import Float32
from sensor_msgs.msg import Image          
from perception_msgs.msg import Rect

import message_filters


import numpy as np
import numpy.matlib
import matplotlib.pyplot as plt

# Visual debug
debug = True


class FaceDetection:
	def __init__(self):        
		# ROS
		self.node_name = "FaceDetection"
		rospy.init_node(self.node_name)
		
		self.bridge = CvBridge()

		# suscribe to image data	
		self.image_sub = rospy.Subscriber("/kinect2/hd/image_color",Image,self.imagecallback)	# FIXME
		# register the publisher
		self.bb_pub = rospy.Publisher('face_detection/bb', Rect, queue_size=1) # Note that Rect is a user defined message
		# load classifier (face detection) # FIXME put the correct path				
		self.face_cascade = cv2.CascadeClassifier('/home/athomews17/Downloads/RCH_tutorial_4_IP_2017WS_template/src/face_detection/haarcascade_frontalface_alt.xml')
		
		if self.face_cascade.empty():
			rospy.logerr("Unable to load the classifier data")
			raise Exception("Face detection loading error")
			
		rospy.loginfo("FaceDetection initialized")		
		
		
	def imagecallback(self,image):
		try:
			cv_im = self.bridge.imgmsg_to_cv2(image,"bgr8")
			# resize the image to half in both axis		        
			cv_im = cv2.resize(cv_im,(0,0),fx=0.5,fy = 0.5)#FIXME
		except CvBridgeError, e:
			data_str = "CvBridge: {}".format(e);
			rospy.loginfo(data_str)
			return
						
		# convert to gray scale
		im_gray = cv2.cvtColor(cv_im,cv2.COLOR_RGB2GRAY)#FIXME

		# positions of detected faces as Rect(x,y,w,h)
		faces = self.face_cascade.detectMultiScale(im_gray, 1.3, 5)
		if len(faces): # if there is any detected face in the image
			r = Rect()			
			r.header = image.header
			r.x = faces[0][0]
			r.y = faces[0][1]
			r.width = faces[0][2]
			r.height = faces[0][3]
			self.bb_pub.publish(r) # Publish the detected face
		
		
		if debug:
			# Plot the detected faces		
			data_str = "Face:";
			i = 0 # face counter
			for (x,y,w,h) in faces:
				cv2.rectangle(cv_im,(x,y),(x+w,y+h),(255,0,0),2)					
				cv2.putText(cv_im, data_str+str(i), (x+w-50,y+h+20), 0, 0.5, color=(255,0,0), thickness=1)
							
			cv2.imshow("Face", cv_im)
					
			cv2.waitKey(1)

	
	
if __name__ == '__main__':
	FD = FaceDetection()
	try:
		rospy.spin()       
	except rospy.ROSInterruptException:
		pass
	rospy.loginfo("FaceDetection shut down")
	cv2.destroyAllWindows()
