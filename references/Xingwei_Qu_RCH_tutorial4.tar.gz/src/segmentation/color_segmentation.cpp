#include <ros/ros.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <sensor_msgs/Image.h>
#include <perception_msgs/Rect.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/objdetect/objdetect.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <iostream>
#include <vector>
using namespace cv;
using namespace std;
void Erosion( int, void* );
void Dilation( int, void* );
class Facedetection{


    ros::NodeHandle nh_;
    image_transport::ImageTransport it_;
    ros::Publisher bb_pub_;
    image_transport::Subscriber image_sub_;
public:
    Facedetection()
        : it_(nh_)
    {

    bb_pub_ = nh_.advertise<perception_msgs::Rect>("color_segmentation/bb",1);

    image_sub_ = it_.subscribe("/kinect2/qhd/image_color_rect",1,&Facedetection::imagecallback,this);
    namedWindow("Face");

    }
    ~Facedetection()
    {
        destroyWindow("Face");
    }
    /*Mat cv_im;
    Mat im_gray;
    CascadeClassifier face_cascade;
    std::vector<Rect> faces;
    perception_msgs::Rect r;*/
    //void imagecallback(const sensor_msgs::ImageConstPtr& image);

void imagecallback(const sensor_msgs::ImageConstPtr& image){
   /* try
    {
        cv_bridge::CvImageConstPtr cv_ptr = cv_bridge::toCvShare(image,sensor_msgs::image_encodings::BGR8);
    }
    catch(cv_bridge::Exception& e){
        ROS_ERROR("CVBRIDGE:{}");
        return;

    }*/



    cv_bridge::CvImagePtr cv_ptr;
    try{

    cv_ptr = cv_bridge::toCvCopy(image,sensor_msgs::image_encodings::BGR8);
        }
    catch(cv_bridge::Exception& e){
    ROS_ERROR("CVBRIDGE:{} %s",e.what());
    return;

        }
    cv::Mat cv_im;
    resize(cv_ptr->image,cv_im,cv::Size(),0.5,0.5);
    //cv::Mat im_gray;
    //cvtColor(cv_ptr->image,im_gray, CV_BGR2GRAY);
    Mat element = getStructuringElement(MORPH_ELLIPSE, Size(20,20));
    Mat erosion_dst,dilation_dst,im_gray;
    erode(cv_im, erosion_dst, element);
    dilate(erosion_dst, dilation_dst, element );
    Mat h_plane;
    Mat s_plane;
    Mat v_plane;
    Mat dst;
    cvtColor(dilation_dst,dilation_dst, CV_RGB2HSV);
    cvtColor(dilation_dst, im_gray,CV_RGB2GRAY);
    h_plane.create(im_gray.size(),im_gray.type());
    s_plane.create(im_gray.size(),im_gray.type());
    v_plane.create(im_gray.size(),im_gray.type());
    vector<Mat>hsv_planes;
    split(dilation_dst, hsv_planes);
    h_plane = hsv_planes[0];
    s_plane = hsv_planes[1];
    v_plane = hsv_planes[2];
    for(int j = 0;j < im_gray.rows;j++){
        const uchar* data_h = h_plane.ptr<uchar>(j);
        const uchar* data_s = s_plane.ptr<uchar>(j);
        const uchar* data_v = v_plane.ptr<uchar>(j);
        for(int i=0; i<im_gray.cols*im_gray.channels(); i++){
            if (data_h[i]*2<45&&data_s[i]>100&&data_v[i]>80){
                im_gray.at<uchar>(j,i)=0;




            }

            else{

                im_gray.at<uchar>(j,i)=255;

            }




        }

    }
    imshow("binary", im_gray);
    cv::waitKey(3);
    vector<vector<Point> > contours;
    vector<Vec4i> hierarachy;



    findContours(im_gray,contours,hierarachy,CV_RETR_CCOMP,CV_CHAIN_APPROX_NONE);
    vector<vector<Point> > contours_poly(contours.size());
    vector<Rect> boundRect(contours.size());
    perception_msgs::Rect r;
    Mat imagegg = Mat::zeros(im_gray.size(),im_gray.type());
    for ( int i=0; i<contours.size(); i++){
        approxPolyDP(Mat(contours[i]),contours_poly[i],3,true);
        boundRect[i] = boundingRect(Mat(contours_poly[i]));






    }
    for ( int i=0; i<contours.size(); i++){

        r.x = boundRect[i].x;
        r.y = boundRect[i].y;
        r.width = boundRect[i].width;
        r.height = boundRect[i].height;
        //rectangle(im_gray,cv::Point(boundRect[i].x,boundRect[i].y),cv::Point(boundRect[i].x+boundRect[i].width,boundRect[i].y+boundRect[i].height),Scalar(0,255,0),2);
        drawContours( imagegg, contours_poly, i, Scalar(255,0,255), 1, 8, vector<Vec4i>(), 0, Point() );
        rectangle(imagegg,boundRect[i].tl(),boundRect[i].br(),Scalar(255,0,255),2);
        bb_pub_.publish(r);





    }




    imshow("binary1", imagegg);
    cv::waitKey(3);






    }
};

int main(int argc, char** argv){
    //Facedetection::imagecallback &imagedeal;
    ros::init(argc,argv,"color_segmentation");
    //ros::NodeHandle n;
    //ros::Subscriber image_sub = n.subscribe("/kinect2/hd/image_color",&Facedetection::imagecallback);
    //ros::Publisher bb_pub = n.advertise<perception_msgs::Rect>("face_detection/bb",1);
    //perception_msgs::Rect r;
    //r = imagedeal.r;
    //bb_pub.publish(r);
    Facedetection ic;
    ros::spin();



    return 0;
}
