#include <ros/ros.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <sensor_msgs/Image.h>
#include <perception_msgs/Rect.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/objdetect/objdetect.hpp>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include <iostream>
#include <vector>
using namespace cv;
using namespace std;
void Erosion( int, void* );
void Dilation( int, void* );
class Facedetection{


    ros::NodeHandle nh_;
    image_transport::ImageTransport it_;
    ros::Publisher bb_pub_;
    image_transport::Subscriber image_sub_;
public:
    Facedetection()
        : it_(nh_)
    {

    bb_pub_ = nh_.advertise<perception_msgs::Rect>("face_detection/bb",1);

    image_sub_ = it_.subscribe("/kinect2/qhd/image_color_rect",1,&Facedetection::imagecallback,this);
    namedWindow("Face");

    }
    ~Facedetection()
    {
        destroyWindow("Face");
    }
    /*Mat cv_im;
    Mat im_gray;
    CascadeClassifier face_cascade;
    std::vector<Rect> faces;
    perception_msgs::Rect r;*/
    //void imagecallback(const sensor_msgs::ImageConstPtr& image);

void imagecallback(const sensor_msgs::ImageConstPtr& image){
   /* try
    {
        cv_bridge::CvImageConstPtr cv_ptr = cv_bridge::toCvShare(image,sensor_msgs::image_encodings::BGR8);
    }
    catch(cv_bridge::Exception& e){
        ROS_ERROR("CVBRIDGE:{}");
        return;

    }*/



    cv_bridge::CvImagePtr cv_ptr;
    try{

    cv_ptr = cv_bridge::toCvCopy(image,sensor_msgs::image_encodings::BGR8);
        }
    catch(cv_bridge::Exception& e){
    ROS_ERROR("CVBRIDGE:{} %s",e.what());
    return;

        }
    cv::Mat cv_im;
    resize(cv_ptr->image,cv_im,cv::Size(),0.5,0.5);
    cv::Mat im_gray;
    cvtColor(cv_ptr->image,im_gray, CV_BGR2GRAY);
    Mat deteced_edges,detected_edges,dst;
    blur(im_gray, deteced_edges , Size(3,3));
    Canny(deteced_edges, detected_edges, 100, 300, 3 );

    dst= Scalar::all(0);

    im_gray.copyTo(dst, detected_edges);
    imshow("edge",dst);
    waitKey(3);

}
};

int main(int argc, char** argv){
    //Facedetection::imagecallback &imagedeal;
    ros::init(argc,argv,"color_segmentation");
    //ros::NodeHandle n;
    //ros::Subscriber image_sub = n.subscribe("/kinect2/hd/image_color",&Facedetection::imagecallback);
    //ros::Publisher bb_pub = n.advertise<perception_msgs::Rect>("face_detection/bb",1);
    //perception_msgs::Rect r;
    //r = imagedeal.r;
    //bb_pub.publish(r);
    Facedetection ic;
    ros::spin();



    return 0;
}
