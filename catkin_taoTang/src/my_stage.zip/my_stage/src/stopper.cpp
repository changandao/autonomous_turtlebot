#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Point.h>
#include <nav_msgs/Odometry.h>
#include "stopper.h"

Stopper::Stopper() {
  keepMoving = true;

  // Advertise a new publisher for the simulated robot's velocity command topic
  commandPub = node.advertise<geometry_msgs::Twist>("cmd_vel", 10);

  // Subscribe to the simulated robot's laser scan topic
  laserSub = node.subscribe("base_scan", 1, &Stopper::scanCallback, this);
  poseSub  = node.subscribe("odom",1,&Stopper::poseCallback, this);     //"odom" is the topic
}

//sunscribe the position
void Stopper::poseCallback(const nav_msgs::Odometry::ConstPtr& odome)
{
  nav_msgs::Odometry::ConstPtr g_pose;
  g_pose = odome;
  //ROS_INFO("My Position: [%f,%f]",g_pose->pose.pose.orientation.z,g_pose->pose.pose.orientation.w);
  angle0 = g_pose->pose.pose.orientation.z;
  ROS_INFO("My Position: [%f]",angle0);

}


// Send a velocity command
void Stopper::moveForward(float linear,float angular) {
  geometry_msgs::Twist msg; // The default constructor will set all commands to 0
  msg.linear.x = linear;
  msg.angular.z = angular;
//  geometry_msgs::Point pose;
//  pose.z = 0.3;
  commandPub.publish(msg);
//  commandPub.publish(pose);
}



// Process the incoming laser scan message
void Stopper::scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
  // Find the closest range between the defined minimum and maximum angles
  int minIndex = ceil((MIN_SCAN_ANGLE_RAD - scan->angle_min) / scan->angle_increment);
  int maxIndex = floor((MAX_SCAN_ANGLE_RAD - scan->angle_min) / scan->angle_increment);

  float closestRange = scan->ranges[minIndex];
  float maxRange = scan->ranges[minIndex];
  int maxRangeIndex;
  
  for (int currIndex = minIndex + 1; currIndex <= maxIndex; currIndex++) {

      if (scan->ranges[currIndex] < closestRange) {         //find closest range, stop when range< threshold
          closestRange = scan->ranges[currIndex];
        }
      
      if (scan->ranges[currIndex] > maxRange) {         //find remotest rangeIndex,  
          maxRange = scan->ranges[currIndex];
	  maxRangeIndex = currIndex;
        }
    }

  angleIndex_1 = maxRangeIndex;
  deltaAngle = (angleIndex_1 - angleIndex_0+1)*scan->angle_increment;
  angleIndex_0 =  angleIndex_1;

  ROS_INFO_STREAM("Closest range: " << closestRange);

  if (closestRange < MIN_PROXIMITY_RANGE_M) {
      ROS_INFO("Stop!");
      keepMoving = false;
      moveForward(0,TURN_SPEED);
    }
  else
    //keepMoving = true;
    moveForward(FORWARD_SPEED_MPS,0);
}

void Stopper::startMoving()
{
  ros::Rate rate(10);
  ROS_INFO("Start moving");

  // Keep spinning loop until user presses Ctrl+C
  while (ros::ok()) {
      // Continue moving if scan changes (we or the obstacle gets moved)
      if (keepMoving);
        //moveForward(FORWARD_SPEED_MPS,0);
        //moveForward(0,TURN_SPEED);
      

      ros::spinOnce(); // Need to call this function often to allow ROS to process incoming messages
      rate.sleep();
    }
}
