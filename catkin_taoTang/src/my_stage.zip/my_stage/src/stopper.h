#ifndef STOPPER_H
#define STOPPER_H

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/Odometry.h>

class Stopper {
  public:
    // Tunable parameters
    const static double FORWARD_SPEED_MPS = 0.5;
    const static double TURN_SPEED = 1.2;
    const static double C_TURN_SPEED = -1.2;
    const static double MIN_SCAN_ANGLE_RAD = -30.0/180*M_PI;
    const static double MAX_SCAN_ANGLE_RAD = +30.0/180*M_PI;
    const static float MIN_PROXIMITY_RANGE_M = 0.6; // Should be smaller than sensor_msgs::LaserScan::range_max
	
    
    Stopper();
    void startMoving();

  private:
    ros::NodeHandle node;
    ros::Publisher commandPub; // Publisher to the robot's velocity command topic
    ros::Subscriber laserSub; // Subscriber to the robot's laser scan topic
    ros::Subscriber poseSub;


    bool keepMoving; // Indicates whether the robot should continue moving

    float angle0;
    int angleIndex_0;
    int angleIndex_1;
    float deltaAngle;
    //nav_msgs::Odometry::ConstPtr g_pose;

    void moveForward(float linear,float angular);
    void poseCallback(const nav_msgs::Odometry::ConstPtr& odome);
    void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan);
};

#endif // STOPPER_H
